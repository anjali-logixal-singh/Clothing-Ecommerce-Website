import React from "react";

export default function Register(props){
    return (
        <div className="container mx-auto">
            <a className="text-black">HElLO</a>
        </div>
    )
}