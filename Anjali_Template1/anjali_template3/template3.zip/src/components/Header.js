import React from 'react';
import Bootstrap from 'bootstrap';

export default function Header(props){
    return <div className='Header'>
        {/* Top Navbar */}
        <nav class="first-half navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
              <ul class="navbar-nav first-nav">
                <li class="nav-item">
                  <h6 class="nav-link">FREE SHIPPING ON ALL U.S ORDERS OVER $50</h6>
                </li>

                <div class="d-flex align-items-baseline top">
                    <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                        USD
                      </a>
                      <div class="dropdown-menu">
                        <a class="dropdown-item" href="#">CAD</a><hr/>
                        <a class="dropdown-item" href="#">AUD</a><hr/>
                        <a class="dropdown-item" href="#">EUR</a><hr/>
                        <a class="dropdown-item" href="#">GBP</a>
                      </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                          English
                        </a>
                        <div class="dropdown-menu">
                          <a class="dropdown-item" href="#">French</a><hr/>
                          <a class="dropdown-item" href="#">Italian</a><hr/>
                          <a class="dropdown-item" href="#">German</a><hr/>
                          <a class="dropdown-item" href="#">Spanish</a>
                        </div>
                      </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                          My Account
                        </a>
                        <div class="dropdown-menu">
                          <a class="dropdown-item" href="#"><i class="fas fa-sign-in-alt pr-2"></i>Sign In</a><hr/>
                          <a class="dropdown-item" href="#"><i class="fas fa-user-plus pr-2"></i>Register</a>
                        </div>
                      </li>
                </div>
                  </ul>
                
            </div>
        </nav>

        {/* Bottom Navbar */}
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container d-flex align-items-baseline">
                <h5 class="font-weight-bold pr-5">COLO<span class="text-danger">SHOP</span></h5>
        
                <div class="collapse navbar-collapse text-center" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto text-dark pr-5 font-weight-bold">
                        <li class="nav-item active px-3">
                        <a class="nav-link" href="#">HOME<span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item px-3">
                        <a class="nav-link" href="#">SHOP</a>
                        </li>
                        <li class="nav-item px-3">
                            <a class="nav-link" href="#">PROMOTION</a>
                        </li>
                        <li class="nav-item px-3">
                            <a class="nav-link" href="#">PAGES</a>
                        </li>
                        <li class="nav-item px-3">
                            <a class="nav-link" href="#">BLOG</a>
                        </li>   
                        <li class="nav-item px-3">
                            <a class="nav-link" href="#">CONTACT</a>
                        </li>
                    </ul>
                </div>

                <div class="d-flex">
                    <a class="nav-link  mr-auto text-dark pr-2" href="#"><i class="fas fa-search"></i></a>
                    <a class="nav-link mr-auto text-dark pr-2" href="#"><i class="fas fa-user"></i></a>
                    <a class="nav-link mr-auto text-dark pr-2" href="#"><i class="fas fa-shopping-cart"></i></a>
                </div>

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
        </nav>

        
    </div>
}